# config.py
GOOGLE_API_KEY = "AIzaSyAJrcRlS8zwlX4gIPdPo2lyl1A22aey-C4"
